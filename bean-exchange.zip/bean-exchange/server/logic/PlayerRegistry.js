// PlayerRegistry.js — in-memory roster of connected players.
//
// Source of truth for cash and bean balances during a round. Persistence
// (writes to Postgres for trades/orders/users) is handled separately in
// db/. The registry is rebuilt on server boot or round reset; it does not
// survive process restarts.

import { randInt } from "../../shared/utils.js";

export class PlayerRegistry {
  constructor() {
    this.players = new Map(); // playerId -> { id, name, isAdmin, cash, beans, socketId, connected }
  }

  add({ id, name, socketId, isAdmin = false }) {
    const existing = this.players.get(id);
    if (existing) {
      existing.socketId = socketId;
      existing.connected = true;
      existing.name = name;
      return existing;
    }
    const player = {
      id, name, isAdmin,
      cash: 0, beans: 0,
      socketId,
      connected: true,
    };
    this.players.set(id, player);
    return player;
  }

  remove(id) {
    const p = this.players.get(id);
    if (p) p.connected = false;
  }

  get(id) {
    return this.players.get(id);
  }

  bySocket(socketId) {
    for (const p of this.players.values()) {
      if (p.socketId === socketId) return p;
    }
    return null;
  }

  list() {
    return [...this.players.values()];
  }

  hasAdmin() {
    return this.list().some((p) => p.isAdmin && p.connected);
  }

  // Reset balances to zero — called at round reset.
  resetBalances() {
    for (const p of this.players.values()) {
      p.cash = 0;
      p.beans = 0;
    }
  }

  // Distribute beans U[min,max] to each non-admin player.
  // Returns the aggregate sum (revealed later at announcement time).
  distribute(min, max) {
    let total = 0;
    for (const p of this.players.values()) {
      if (p.isAdmin) continue;
      const x = randInt(min, max);
      p.beans += x;
      total += x;
    }
    return total;
  }

  // Apply a fill to buyer/seller balances. The matching engine produced
  // the fill object; we just adjust cash and beans here.
  applyFill(fill) {
    const buyer = this.players.get(fill.buyer);
    const seller = this.players.get(fill.seller);
    if (buyer) {
      buyer.cash -= fill.price * fill.qty;
      buyer.beans += fill.qty;
    }
    if (seller) {
      seller.cash += fill.price * fill.qty;
      seller.beans -= fill.qty;
    }
  }
}
