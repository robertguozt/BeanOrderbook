// GameTimer.js — drives the round clock and fires timeline events.
//
// Lifecycle:
//   start()  - begin or resume from current elapsed
//   pause()  - stop ticking but keep elapsed
//   reset()  - back to lobby state (elapsed = 0, no events fired)
//
// On every tick we emit "tick" and check whether any pending timeline
// event's `t` has been crossed. When it has, we fire it once and emit
// "event". The orchestrator (server.js) handles the consequences
// (distributions, announcements, market close).

import { EventEmitter } from "events";
import { DEFAULT_TIMELINE, DEFAULT_CONFIG } from "../../shared/constants.js";

export class GameTimer extends EventEmitter {
  constructor() {
    super();
    this.elapsed = 0;
    this.phase = "lobby"; // lobby | running | paused | ended
    this.timeline = [...DEFAULT_TIMELINE];
    this.config = { ...DEFAULT_CONFIG };
    this.firedKeys = new Set();
    this._handle = null;
  }

  setConfig(cfg) {
    this.config = { ...this.config, ...cfg };
  }

  status() {
    return {
      elapsed: this.elapsed,
      phase: this.phase,
      remaining: Math.max(0, this.config.roundLength - this.elapsed),
      config: { ...this.config },
      timeline: this.timeline.map((e) => ({ ...e, fired: this.firedKeys.has(e.key) })),
    };
  }

  start() {
    if (this.phase === "running") return;
    this.phase = "running";
    this._handle = setInterval(() => this._tick(), 1000);
    this.emit("phase", this.phase);
  }

  pause() {
    if (this.phase !== "running") return;
    this.phase = "paused";
    clearInterval(this._handle);
    this._handle = null;
    this.emit("phase", this.phase);
  }

  reset() {
    if (this._handle) clearInterval(this._handle);
    this._handle = null;
    this.elapsed = 0;
    this.phase = "lobby";
    this.firedKeys = new Set();
    this.emit("phase", this.phase);
    this.emit("reset");
  }

  _tick() {
    this.elapsed += 1;
    this.emit("tick", this.elapsed);

    for (const ev of this.timeline) {
      if (!this.firedKeys.has(ev.key) && this.elapsed >= ev.t) {
        this.firedKeys.add(ev.key);
        this.emit("event", { ...ev, firedAt: this.elapsed });
      }
    }

    if (this.elapsed >= this.config.roundLength) {
      this.phase = "ended";
      clearInterval(this._handle);
      this._handle = null;
      this.emit("phase", this.phase);
    }
  }
}
