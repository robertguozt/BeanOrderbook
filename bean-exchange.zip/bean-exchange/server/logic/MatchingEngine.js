// MatchingEngine.js — Price-Time Priority (FIFO)
//
// Maintains two sorted books:
//   bids: descending by price, then ascending by timestamp (older first)
//   asks: ascending by price,  then ascending by timestamp
//
// When a new order arrives:
//   1. Walk the opposite side from the top.
//   2. If the resting price is acceptable (or the incoming order is market),
//      execute at the resting price.
//   3. Continue until incoming qty is exhausted or no more crossable levels.
//   4. Any remaining limit qty rests on the book.
//
// Self-cross protection: orders from the same owner do NOT match against
// each other; the engine skips past them and re-inserts them after.

import { uid } from "../../shared/utils.js";

export class MatchingEngine {
  constructor() {
    this.bids = []; // { id, owner, side: 'buy',  price, qty, ts }
    this.asks = []; // { id, owner, side: 'sell', price, qty, ts }
  }

  reset() {
    this.bids = [];
    this.asks = [];
  }

  snapshot() {
    return {
      bids: this.bids.map((o) => ({ ...o })),
      asks: this.asks.map((o) => ({ ...o })),
    };
  }

  // Aggregate a side by price level for transmission to the client.
  // The client doesn't need (and shouldn't see) per-order ownership beyond
  // the fact that *some* of the size at a level belongs to them.
  depth(side, viewerId = null, maxLevels = 12) {
    const book = side === "bids" ? this.bids : this.asks;
    const map = new Map();
    for (const o of book) {
      const cur = map.get(o.price) || { price: o.price, qty: 0, mine: 0 };
      cur.qty += o.qty;
      if (o.owner === viewerId) cur.mine += o.qty;
      map.set(o.price, cur);
    }
    return [...map.values()].slice(0, maxLevels);
  }

  cancel(orderId, ownerId) {
    const removeFrom = (arr) => {
      const i = arr.findIndex((o) => o.id === orderId && o.owner === ownerId);
      if (i >= 0) {
        const [removed] = arr.splice(i, 1);
        return removed;
      }
      return null;
    };
    return removeFrom(this.bids) || removeFrom(this.asks);
  }

  // Cancel all orders for a specific owner — used at round end / disconnect.
  cancelAllForOwner(ownerId) {
    this.bids = this.bids.filter((o) => o.owner !== ownerId);
    this.asks = this.asks.filter((o) => o.owner !== ownerId);
  }

  // Insert into a sorted side (called for unfilled limit remainders).
  _insertSorted(side, order) {
    const arr = side === "buy" ? this.bids : this.asks;
    const cmp = (a, b) => {
      if (side === "buy") {
        if (b.price !== a.price) return b.price - a.price;
      } else {
        if (a.price !== b.price) return a.price - b.price;
      }
      return a.ts - b.ts;
    };
    let i = 0;
    while (i < arr.length && cmp(arr[i], order) <= 0) i++;
    arr.splice(i, 0, order);
  }

  // Submit an order; returns { fills, restingId | null, leftover, orderId }.
  submit({ owner, side, price, qty, isMarket }, ts = Date.now()) {
    if (!["buy", "sell"].includes(side)) throw new Error("bad side");
    if (!Number.isFinite(qty) || qty <= 0) throw new Error("bad qty");
    if (!isMarket && (!Number.isFinite(price) || price <= 0)) throw new Error("bad price");

    const incoming = {
      id: uid(),
      owner,
      side,
      price: isMarket ? (side === "buy" ? Infinity : 0) : Number(price),
      qty: Math.floor(qty),
      ts,
      isMarket: !!isMarket,
    };

    let remaining = incoming.qty;
    const fills = [];
    const oppositeArr = side === "buy" ? this.asks : this.bids;
    const skipped = [];

    while (remaining > 0 && oppositeArr.length > 0) {
      const top = oppositeArr[0];
      const priceOk = incoming.isMarket
        || (side === "buy" ? incoming.price >= top.price
                           : incoming.price <= top.price);
      if (!priceOk) break;

      if (top.owner === incoming.owner) {
        skipped.push(oppositeArr.shift());
        continue;
      }

      const fillQty = Math.min(remaining, top.qty);
      fills.push({
        id: uid(),
        ts,
        buyer:  side === "buy"  ? incoming.owner : top.owner,
        seller: side === "sell" ? incoming.owner : top.owner,
        price: top.price,
        qty: fillQty,
        aggressor: side,
        restingId: top.id,
      });
      top.qty -= fillQty;
      remaining -= fillQty;
      if (top.qty === 0) oppositeArr.shift();
    }

    // restore any skipped self-cross orders to their proper sorted position
    for (const s of skipped) this._insertSorted(s.side, s);

    let restingId = null;
    if (remaining > 0 && !incoming.isMarket) {
      const resting = { ...incoming, qty: remaining };
      this._insertSorted(side, resting);
      restingId = resting.id;
    }

    return { fills, restingId, leftover: remaining, orderId: incoming.id };
  }
}
