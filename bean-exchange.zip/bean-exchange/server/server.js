// server.js — Bean Exchange backend entry point.
//
// Express serves a tiny HTTP layer (health check + a couple of REST endpoints
// for round history). Socket.io handles all real-time gameplay: login,
// orders, cancellations, admin controls, broadcasts.
//
// State model:
//   - One global game (single-room) — fine for free-tier scale.
//   - PlayerRegistry holds live balances and identities.
//   - MatchingEngine holds the order book.
//   - GameTimer drives the clock and fires distribution/announcement events.
//
// All state changes are immediately broadcast via Socket.io. DB writes are
// fire-and-forget so the engine never blocks on persistence.

import "dotenv/config";
import express from "express";
import http from "http";
import cors from "cors";
import { Server as SocketServer } from "socket.io";

import { MatchingEngine } from "./logic/MatchingEngine.js";
import { GameTimer }     from "./logic/GameTimer.js";
import { PlayerRegistry } from "./logic/PlayerRegistry.js";

import { EVENTS, computePnL } from "../shared/constants.js";
import { uid } from "../shared/utils.js";

import {
  ensureUser, startRound, endRound,
  recordOrder, recordTrade, recordResults,
} from "./db/queries.js";

import historyRoute from "./routes/history.js";

// ---------- Config ----------
const PORT = process.env.PORT || 3001;
const ADMIN_PASS = process.env.ADMIN_PASS || "changeme";
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || "*";

// ---------- App ----------
const app = express();
app.use(cors({ origin: CLIENT_ORIGIN, credentials: true }));
app.use(express.json());
app.get("/health", (_req, res) => res.json({ ok: true, ts: Date.now() }));
app.use("/api/history", historyRoute);

const httpServer = http.createServer(app);
const io = new SocketServer(httpServer, {
  cors: { origin: CLIENT_ORIGIN, credentials: true },
  // Render free tier benefits from longer pings since cold starts can be slow
  pingTimeout: 30_000,
  pingInterval: 25_000,
});

// ---------- Engine state ----------
const engine = new MatchingEngine();
const timer = new GameTimer();
const registry = new PlayerRegistry();

// Track the active DB round (null if persistence disabled)
let currentRoundId = null;
// Map in-memory player.id → users.id in Postgres
const userIdMap = new Map();
// Pending distribution totals — revealed only at announcement time
const pending = { dist1: null, dist2: null };
const announcements = { ann1: null, ann2: null };

// ---------- Broadcast helpers ----------
function broadcastBook() {
  // Emit per-socket so each viewer can see "their" size at each level.
  for (const player of registry.list()) {
    if (!player.connected) continue;
    io.to(player.socketId).emit(EVENTS.ORDER_BOOK, {
      bids: engine.depth("bids", player.id),
      asks: engine.depth("asks", player.id),
    });
  }
}

function broadcastPlayers() {
  // Admin sees the full roster; everyone else sees themselves only.
  const all = registry.list().map((p) => ({
    id: p.id, name: p.name, isAdmin: p.isAdmin,
    cash: p.cash, beans: p.beans, pnl: computePnL(p),
    connected: p.connected,
  }));
  for (const p of registry.list()) {
    if (!p.connected) continue;
    if (p.isAdmin) {
      io.to(p.socketId).emit(EVENTS.PLAYERS, all);
    } else {
      io.to(p.socketId).emit(EVENTS.PLAYERS,
        all.filter((x) => x.id === p.id));
    }
  }
}

function broadcastTimerStatus() {
  io.emit(EVENTS.STATE, {
    timer: timer.status(),
    announcements,
  });
}

// ---------- Timer event handlers ----------
timer.on("tick", (elapsed) => {
  io.emit(EVENTS.TICK, { elapsed });
});

timer.on("phase", () => broadcastTimerStatus());

timer.on("event", async (ev) => {
  // Distributions are private — we only reveal totals at announcement time.
  if (ev.key === "dist1") {
    pending.dist1 = registry.distribute(timer.config.distMin, timer.config.distMax);
    broadcastPlayers();
  } else if (ev.key === "dist2") {
    pending.dist2 = registry.distribute(timer.config.distMin, timer.config.distMax);
    broadcastPlayers();
  } else if (ev.key === "ann1") {
    announcements.ann1 = pending.dist1 ?? 0;
  } else if (ev.key === "ann2") {
    announcements.ann2 = pending.dist2 ?? 0;
  } else if (ev.key === "close") {
    // Cancel resting orders, finalize results
    for (const p of registry.list()) engine.cancelAllForOwner(p.id);
    broadcastBook();
    if (currentRoundId) {
      endRound(currentRoundId, announcements.ann1, announcements.ann2).catch(console.error);
      recordResults(currentRoundId, registry.list(), userIdMap, computePnL).catch(console.error);
    }
  }

  io.emit(EVENTS.GAME_EVENT, {
    key: ev.key, label: ev.label, t: ev.t, firedAt: ev.firedAt,
    payload: ev.key === "ann1" ? { total: announcements.ann1 }
           : ev.key === "ann2" ? { total: announcements.ann2 }
           : null,
  });
  broadcastTimerStatus();
});

// ---------- Socket handlers ----------
io.on("connection", (socket) => {
  console.log(`[io] connection ${socket.id}`);

  // --- Login ---
  socket.on(EVENTS.LOGIN, async ({ name, adminPass }) => {
    try {
      const trimmed = (name || "").trim();
      if (!trimmed) {
        return socket.emit(EVENTS.ERROR, { msg: "Name required" });
      }
      const wantAdmin = trimmed.toLowerCase() === "admin";
      if (wantAdmin) {
        if (adminPass !== ADMIN_PASS) {
          return socket.emit(EVENTS.ERROR, { msg: "Bad admin password" });
        }
        if (registry.hasAdmin()) {
          return socket.emit(EVENTS.ERROR, { msg: "Admin session already active" });
        }
      }

      const id = uid();
      const player = registry.add({
        id, name: trimmed, socketId: socket.id, isAdmin: wantAdmin,
      });
      socket.data.playerId = id;

      // best-effort DB user record
      try {
        const userId = await ensureUser(trimmed, wantAdmin);
        if (userId) userIdMap.set(id, userId);
      } catch (e) { console.warn("[db] ensureUser failed:", e.message); }

      socket.emit(EVENTS.YOU, { player });
      socket.emit(EVENTS.ORDER_BOOK, {
        bids: engine.depth("bids", id),
        asks: engine.depth("asks", id),
      });
      socket.emit(EVENTS.STATE, { timer: timer.status(), announcements });
      broadcastPlayers();
    } catch (err) {
      socket.emit(EVENTS.ERROR, { msg: err.message });
    }
  });

  // --- Place order ---
  socket.on(EVENTS.PLACE_ORDER, async ({ side, price, qty, isMarket }) => {
    const player = registry.bySocket(socket.id);
    if (!player) return socket.emit(EVENTS.ERROR, { msg: "Not logged in" });
    if (player.isAdmin) return socket.emit(EVENTS.ERROR, { msg: "Admin cannot trade" });
    if (timer.phase !== "running") {
      return socket.emit(EVENTS.ERROR, { msg: "Market not open" });
    }

    try {
      const result = engine.submit({
        owner: player.id, side, price, qty, isMarket,
      });

      // Apply fills to balances
      for (const fill of result.fills) {
        registry.applyFill(fill);
      }

      // Broadcast fills to everyone — anonymous tape with marker for the
      // involved sockets so each side can highlight its own trades.
      for (const fill of result.fills) {
        io.emit(EVENTS.TRADE, {
          id: fill.id,
          price: fill.price,
          qty: fill.qty,
          aggressor: fill.aggressor,
          ts: fill.ts,
          buyerSocket: registry.get(fill.buyer)?.socketId,
          sellerSocket: registry.get(fill.seller)?.socketId,
        });
        if (currentRoundId) {
          recordTrade(currentRoundId, fill, userIdMap).catch(console.error);
        }
      }

      if (currentRoundId) {
        recordOrder(currentRoundId, userIdMap.get(player.id), {
          side, price, qty, isMarket,
        }).catch(console.error);
      }

      broadcastBook();
      broadcastPlayers();
    } catch (err) {
      socket.emit(EVENTS.ERROR, { msg: err.message });
    }
  });

  // --- Cancel order ---
  socket.on(EVENTS.CANCEL_ORDER, ({ orderId }) => {
    const player = registry.bySocket(socket.id);
    if (!player) return;
    const removed = engine.cancel(orderId, player.id);
    if (removed) broadcastBook();
  });

  // --- Admin controls ---
  socket.on(EVENTS.ADMIN_START, async () => {
    const player = registry.bySocket(socket.id);
    if (!player?.isAdmin) return socket.emit(EVENTS.ERROR, { msg: "Admin only" });
    if (timer.phase === "lobby" || timer.phase === "ended") {
      // fresh round
      registry.resetBalances();
      engine.reset();
      pending.dist1 = pending.dist2 = null;
      announcements.ann1 = announcements.ann2 = null;
      try {
        currentRoundId = await startRound(timer.config);
      } catch (e) { console.warn("[db] startRound failed:", e.message); }
      timer.reset();
    }
    timer.start();
    broadcastBook();
    broadcastPlayers();
    broadcastTimerStatus();
  });

  socket.on(EVENTS.ADMIN_PAUSE, () => {
    const player = registry.bySocket(socket.id);
    if (!player?.isAdmin) return;
    if (timer.phase === "running") timer.pause();
    else if (timer.phase === "paused") timer.start();
    broadcastTimerStatus();
  });

  socket.on(EVENTS.ADMIN_RESET, () => {
    const player = registry.bySocket(socket.id);
    if (!player?.isAdmin) return;
    timer.reset();
    engine.reset();
    registry.resetBalances();
    pending.dist1 = pending.dist2 = null;
    announcements.ann1 = announcements.ann2 = null;
    currentRoundId = null;
    broadcastBook();
    broadcastPlayers();
    broadcastTimerStatus();
  });

  socket.on(EVENTS.ADMIN_CONFIG, (cfg) => {
    const player = registry.bySocket(socket.id);
    if (!player?.isAdmin) return;
    timer.setConfig(cfg);
    broadcastTimerStatus();
  });

  socket.on("disconnect", () => {
    const player = registry.bySocket(socket.id);
    if (player) {
      registry.remove(player.id);
      // Clean up resting orders to keep the book honest
      engine.cancelAllForOwner(player.id);
      broadcastBook();
      broadcastPlayers();
    }
  });
});

httpServer.listen(PORT, () => {
  console.log(`Bean Exchange server on :${PORT}`);
  console.log(`  CLIENT_ORIGIN=${CLIENT_ORIGIN}`);
  console.log(`  DB persistence: ${process.env.DATABASE_URL ? "on" : "off"}`);
});
