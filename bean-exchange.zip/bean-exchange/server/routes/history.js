// REST endpoints for past round results — useful for a future leaderboard.

import { Router } from "express";
import { query } from "../db/pool.js";

const router = Router();

router.get("/", async (_req, res) => {
  try {
    const r = await query(
      `select id, started_at, ended_at, ann1_total, ann2_total
         from rounds
         where ended_at is not null
         order by ended_at desc
         limit 25`
    );
    res.json({ rounds: r.rows });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.get("/:roundId", async (req, res) => {
  try {
    const { roundId } = req.params;
    const round = await query("select * from rounds where id = $1", [roundId]);
    if (round.rowCount === 0) return res.status(404).json({ error: "not found" });
    const results = await query(
      `select rr.*, u.name
         from round_results rr
         join users u on u.id = rr.user_id
         where rr.round_id = $1
         order by rr.pnl desc`,
      [roundId]
    );
    res.json({ round: round.rows[0], results: results.rows });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

export default router;
