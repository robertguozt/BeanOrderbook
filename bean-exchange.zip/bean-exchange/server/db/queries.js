// Persistence helpers. All writes are best-effort: if the DB is
// unavailable, the game still runs in memory.

import { query } from "./pool.js";

export async function ensureUser(name, isAdmin) {
  const sel = await query("select id from users where name = $1", [name]);
  if (sel.rowCount > 0) return sel.rows[0].id;
  const ins = await query(
    "insert into users (name, is_admin) values ($1, $2) returning id",
    [name, isAdmin]
  );
  return ins.rows[0]?.id || null;
}

export async function startRound(config) {
  const r = await query(
    "insert into rounds (config) values ($1) returning id",
    [config]
  );
  return r.rows[0]?.id || null;
}

export async function endRound(roundId, ann1, ann2) {
  if (!roundId) return;
  await query(
    "update rounds set ended_at = now(), ann1_total = $1, ann2_total = $2 where id = $3",
    [ann1, ann2, roundId]
  );
}

export async function recordOrder(roundId, userId, order) {
  if (!roundId || !userId) return;
  await query(
    `insert into orders (round_id, user_id, side, price, qty, is_market, remaining)
     values ($1, $2, $3, $4, $5, $6, $7)`,
    [roundId, userId, order.side,
     order.isMarket ? null : order.price, order.qty,
     order.isMarket, order.qty]
  );
}

export async function recordTrade(roundId, fill, userIdMap) {
  if (!roundId) return;
  const buyerId = userIdMap.get(fill.buyer);
  const sellerId = userIdMap.get(fill.seller);
  if (!buyerId || !sellerId) return;
  await query(
    `insert into trades (round_id, buyer_id, seller_id, price, qty, aggressor)
     values ($1, $2, $3, $4, $5, $6)`,
    [roundId, buyerId, sellerId, fill.price, fill.qty, fill.aggressor]
  );
}

export async function recordResults(roundId, players, userIdMap, computePnL) {
  if (!roundId) return;
  for (const p of players) {
    const userId = userIdMap.get(p.id);
    if (!userId) continue;
    const pnl = computePnL(p);
    await query(
      `insert into round_results (round_id, user_id, cash, beans, pnl)
       values ($1, $2, $3, $4, $5)
       on conflict (round_id, user_id) do update
         set cash = excluded.cash, beans = excluded.beans, pnl = excluded.pnl`,
      [roundId, userId, p.cash, p.beans, pnl]
    );
  }
}
