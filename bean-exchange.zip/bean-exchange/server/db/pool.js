// Postgres connection pool. Uses DATABASE_URL from env (Supabase format).
//
// Render's free tier and Supabase both prefer pooled connections. We expose
// a small `query` helper plus the raw pool for transactions.

import pg from "pg";

const { Pool } = pg;

const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
  console.warn("[db] DATABASE_URL is not set — persistence will be disabled.");
}

export const pool = connectionString
  ? new Pool({
      connectionString,
      // Supabase requires SSL in production
      ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
      max: 8,
      idleTimeoutMillis: 30_000,
    })
  : null;

export async function query(text, params) {
  if (!pool) return { rows: [], rowCount: 0 };
  const res = await pool.query(text, params);
  return res;
}

export async function withTx(fn) {
  if (!pool) return fn({ query: async () => ({ rows: [], rowCount: 0 }) });
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await fn(client);
    await client.query("COMMIT");
    return result;
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}
