-- Bean Exchange schema
-- Run this once against a fresh Supabase project (SQL editor or psql).

create extension if not exists "uuid-ossp";

create table if not exists rounds (
  id          uuid primary key default uuid_generate_v4(),
  started_at  timestamptz not null default now(),
  ended_at    timestamptz,
  config      jsonb       not null,
  ann1_total  integer,
  ann2_total  integer
);

create table if not exists users (
  id          uuid primary key default uuid_generate_v4(),
  name        text not null,
  is_admin    boolean not null default false,
  created_at  timestamptz not null default now()
);

create table if not exists orders (
  id          uuid primary key default uuid_generate_v4(),
  round_id    uuid references rounds(id) on delete cascade,
  user_id     uuid references users(id),
  side        text not null check (side in ('buy', 'sell')),
  price       numeric(10,2),
  qty         integer not null,
  is_market   boolean not null default false,
  status      text not null default 'open' check (status in ('open','filled','partial','cancelled')),
  remaining   integer not null,
  placed_at   timestamptz not null default now()
);

create index if not exists orders_round_idx on orders(round_id);
create index if not exists orders_user_idx  on orders(user_id);

create table if not exists trades (
  id          uuid primary key default uuid_generate_v4(),
  round_id    uuid references rounds(id) on delete cascade,
  buyer_id    uuid references users(id),
  seller_id   uuid references users(id),
  price       numeric(10,2) not null,
  qty         integer not null,
  aggressor   text not null check (aggressor in ('buy', 'sell')),
  executed_at timestamptz not null default now()
);

create index if not exists trades_round_idx on trades(round_id);
create index if not exists trades_time_idx  on trades(executed_at desc);

create table if not exists round_results (
  round_id    uuid references rounds(id) on delete cascade,
  user_id     uuid references users(id),
  cash        numeric(12,2) not null,
  beans       integer not null,
  pnl         numeric(12,2) not null,
  primary key (round_id, user_id)
);
