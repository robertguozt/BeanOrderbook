// Shared between client and server — game rules and event timeline.
// Keep this file dependency-free so it can be imported anywhere.

export const BEAN_TARGET = 100;
export const SHORTFALL_PENALTY_PER_BEAN = 1;

// Default round timeline (seconds from market open)
export const DEFAULT_TIMELINE = [
  { t: 0,   key: "open",  label: "Market Opens" },
  { t: 120, key: "dist1", label: "Distribution 1" },
  { t: 300, key: "ann1",  label: "Announcement 1" },
  { t: 360, key: "dist2", label: "Distribution 2" },
  { t: 540, key: "ann2",  label: "Announcement 2" },
  { t: 600, key: "close", label: "Market Closes" },
];

export const DEFAULT_CONFIG = {
  distMin: 0,
  distMax: 100,
  roundLength: 600,
};

// Socket event names — single source of truth for the wire protocol.
export const EVENTS = {
  // Server → client
  STATE:        "state",
  TICK:         "tick",
  TRADE:        "trade",
  ORDER_BOOK:   "orderbook",
  GAME_EVENT:   "game_event",
  ERROR:        "error",
  YOU:          "you",
  PLAYERS:      "players",
  // Client → server
  LOGIN:        "login",
  PLACE_ORDER:  "place_order",
  CANCEL_ORDER: "cancel_order",
  ADMIN_START:  "admin:start",
  ADMIN_PAUSE:  "admin:pause",
  ADMIN_RESET:  "admin:reset",
  ADMIN_CONFIG: "admin:config",
};

// Terminal PnL formula from the spec
export function computePnL({ cash, beans }) {
  const shortfall = Math.min(0, (beans - BEAN_TARGET) * SHORTFALL_PENALTY_PER_BEAN);
  return cash + shortfall;
}
