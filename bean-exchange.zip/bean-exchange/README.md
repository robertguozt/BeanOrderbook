# Bean Exchange

Real-time trading simulator built around a private-distribution game. Players
trade beans on a price-time-priority orderbook over a 10-minute round; their
terminal PnL is `cash + min(0, (beans − 100) × $1)`.

```
client/   React (Vite) + Tailwind, deployed on Vercel
server/   Node + Express + Socket.io, deployed on Render
shared/   Constants and helpers used by both sides
```

## Quick start (local)

Prerequisites: Node 20+, a Supabase project (free tier).

```bash
# 1. Database
psql "$DATABASE_URL" -f server/db/schema.sql

# 2. Server
cd server
cp .env.example .env       # fill in DATABASE_URL, ADMIN_PASS
npm install
npm run dev                # listens on :3001

# 3. Client (in a second shell)
cd client
cp .env.example .env       # VITE_SERVER_URL=http://localhost:3001
npm install
npm run dev                # opens http://localhost:5173
```

Log in by typing any name to play, or `admin` (with `ADMIN_PASS`) to control
the round. The first admin session "owns" the game; the server rejects a
second concurrent admin login.

## How a round runs

| Time  | Event           | What happens |
|-------|-----------------|--------------|
| 00:00 | Market opens    | Trading allowed |
| 02:00 | Distribution 1  | Each player privately receives `U[distMin, distMax]` beans |
| 05:00 | Announcement 1  | Aggregate of distribution 1 broadcast |
| 06:00 | Distribution 2  | Second private draw |
| 09:00 | Announcement 2  | Aggregate broadcast |
| 10:00 | Market closes   | PnL recorded; resting orders cancelled |

The matching engine is a price-time priority FIFO with self-cross protection.
Limit and market orders are both supported. Trades execute at the resting
order's price.

## Architecture

```
            ┌──────────────────────────────┐
            │         Vercel (CDN)         │
            │   client/dist  (React SPA)   │
            └──────────────┬───────────────┘
                           │  WSS (socket.io)
                           ▼
            ┌──────────────────────────────┐
            │      Render free tier        │
            │  Express + Socket.io server  │
            │  ┌────────────────────────┐  │
            │  │ MatchingEngine (RAM)   │  │
            │  │ GameTimer      (RAM)   │  │
            │  │ PlayerRegistry (RAM)   │  │
            │  └─────────┬──────────────┘  │
            └────────────┼─────────────────┘
                         │  pg (TLS, pooled)
                         ▼
            ┌──────────────────────────────┐
            │     Supabase Postgres        │
            │  rounds · trades · orders    │
            │  users  · round_results      │
            └──────────────────────────────┘
```

State of record is in-process memory on the server; Postgres is best-effort
audit storage. If the DB is unreachable, the game still runs.

## Wire protocol

All event names live in `shared/constants.js` under `EVENTS`. Highlights:

| Direction | Event           | Payload |
|-----------|-----------------|---------|
| C → S | `login`         | `{ name, adminPass? }` |
| C → S | `place_order`   | `{ side, price, qty, isMarket }` |
| C → S | `cancel_order`  | `{ orderId }` |
| C → S | `admin:start` / `admin:pause` / `admin:reset` / `admin:config` | — |
| S → C | `you`           | `{ player }` |
| S → C | `orderbook`     | `{ bids, asks }` (per-viewer; includes `mine` quantity at each level) |
| S → C | `trade`         | `{ id, price, qty, aggressor, ts, buyerSocket, sellerSocket }` |
| S → C | `tick`          | `{ elapsed }` |
| S → C | `game_event`    | `{ key, label, t, firedAt, payload? }` |
| S → C | `state`         | `{ timer, announcements }` |
| S → C | `players`       | full roster (admin) or just self (player) |
| S → C | `error`         | `{ msg }` |

## Deploy

### 1. Database (Supabase)

Create a new project. Open the SQL editor and run the contents of
`server/db/schema.sql`. Copy the **pooled** connection string from
Settings → Database (use port 6543) — that's `DATABASE_URL`.

### 2. Backend (Render)

Push this repo to GitHub. In Render, "New → Blueprint" and pick the repo.
The included `render.yaml` provisions the service. Set in the dashboard:
- `DATABASE_URL` — your Supabase pooled string
- `ADMIN_PASS` — pick something
- `CLIENT_ORIGIN` — your Vercel URL once you have it (use `*` for first deploy)

Render's free tier sleeps after 15 min of inactivity; the first request after
sleep will take ~30 s. The Socket.io client retries automatically.

### 3. Frontend (Vercel)

In Vercel, "New Project → Import Git Repository". `vercel.json` points the
build at `client/`. Add an env var `VITE_SERVER_URL` pointing at your Render
URL, then deploy. After deploying, paste the Vercel URL into Render's
`CLIENT_ORIGIN` and trigger a redeploy on Render.

### 4. Latency

For a single round of <50 concurrent players, Render's free tier handles the
matching load comfortably. Tick is 1 Hz; orders match in O(levels). If you
push past that, the bottleneck is the broadcast fan-out, not the engine.

## License

MIT.
